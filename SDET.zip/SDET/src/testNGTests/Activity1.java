package testNGTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Activity1 {

	WebDriver driver;

	@Test
	public void f() {

		String title = driver.getTitle();
		System.out.println("Title of the page :" + title);
		Assert.assertEquals("Training Support", title);
		driver.findElement(By.xpath(".//*[@id= 'about-link']")).click();
		String title1 = driver.getTitle();
		System.out.println("The title of the new page is :" + title1);
		Assert.assertEquals("About Training Support", title1);

	}

	@BeforeMethod
	public void beforeMethod() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/");
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void afterMethod() {

		driver.close();

	}

}
