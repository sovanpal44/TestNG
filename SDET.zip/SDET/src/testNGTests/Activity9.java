package testNGTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Activity9 {
	WebDriver driver;

	@Test(priority = 0)
	public void simpleAlertTestCase() {

		driver.findElement(By.id("simple")).click();
		org.openqa.selenium.Alert simpleAlert = driver.switchTo().alert();
		Assert.assertEquals(simpleAlert.getText(), "This is a JavaScript Alert!");
		simpleAlert.accept();

		Reporter.log("Test case ended |");
	}

	@Test(priority = 1)
	public void confirmAlertTestCase() {

		driver.findElement(By.id("confirm")).click();
		org.openqa.selenium.Alert confirmAlert = driver.switchTo().alert();
		Assert.assertEquals(confirmAlert.getText(), "This is a JavaScript Confirmation!");
		confirmAlert.accept();
		Reporter.log("Test case ended |");
	}

	@Test(priority = 2)
	public void promptAlertTestCase() {

		driver.findElement(By.id("prompt")).click();
		org.openqa.selenium.Alert prompt = driver.switchTo().alert();
		Assert.assertEquals(prompt.getText(), "This is a JavaScript Prompt!");
		prompt.sendKeys("Test");
		prompt.accept();
		Reporter.log("Test case ended |");

	}

	@BeforeMethod
	public void beforeMethod() {

		driver.switchTo().defaultContent();
	}

	@BeforeTest
	public void beforeTest() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/javascript-alerts");
		driver.manage().window().maximize();
		Reporter.log("Page title is " + driver.getTitle() + " |");
	}

	@AfterTest
	public void afterTest() {
		Reporter.log("Ending Test |");
		driver.close();
	}

}
