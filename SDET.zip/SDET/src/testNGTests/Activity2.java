package testNGTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Activity2 {

	WebDriver driver;

	@Test(priority = 0)
	public void testcase1() {

		String title = driver.getTitle();
		System.out.println("Title of the page :" + title);
		Assert.assertEquals("Target Practice", title);

	}

	@Test(priority = 1)
	public void testcase2() {

		WebElement blackbutton = driver.findElement(By.cssSelector("button.black"));
		Assert.assertTrue(blackbutton.isDisplayed());

	}

	@Test(priority = 3, enabled = false)
	public void testcase4() {

		String subHeading = driver.findElement(By.className("sub")).getText();

		Assert.assertTrue(subHeading.contains("Practice"));

	}

	@Test
	public void testcsae5() {

		throw new SkipException("Skipping test case");
	}

	@BeforeClass
	public void beforeClass() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
		driver.manage().window().maximize();

	}

	@AfterClass
	public void afterClass() {

		driver.close();
	}

}
