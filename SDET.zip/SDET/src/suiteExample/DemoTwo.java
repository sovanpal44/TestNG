package suiteExample;

import org.testng.annotations.Test;

public class DemoTwo {
	@Test
	public void newTestCase() {

		System.out.println("This test case is from demo two class");
	}
}
