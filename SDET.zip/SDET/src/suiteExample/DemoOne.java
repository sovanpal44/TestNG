package suiteExample;

import org.testng.annotations.Test;

public class DemoOne {
	@Test
	public void testCase1() {

		System.out.println("This is the first test case");
	}

	@Test
	public void testCase2() {

		System.out.println("This is the second test case");
	}

}
