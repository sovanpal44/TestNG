package suiteExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Activity5 {
	WebDriver driver;

	@Test(groups = { "headerTests", "buttonTests" })
	public void pageTitle() {

		String title = driver.getTitle();
		System.out.println("Title of the page :" + title);
		Assert.assertEquals("Target Practice", title);
	}

	@Test(dependsOnMethods = { "pageTitle" }, groups = { "headerTests" })
	public void thirdHeaderText() {

		WebElement header3 = driver.findElement(By.xpath(".//*[@id='third-header']"));
		Assert.assertEquals(header3.getText(), "Third header");
	}

	@Test(dependsOnMethods = { "pageTitle" }, groups = { "headerTests" })
	public void fifthheader() {

		WebElement header3 = driver.findElement(By.xpath(".//*[contains(text(),'Fifth header')]"));
		Assert.assertEquals(header3.getCssValue("color"), "rgba(33, 186, 69, 1)");
	}

	@Test(dependsOnMethods = { "pageTitle" }, groups = { "buttonTests" })
	public void oliveButtonText() {

		WebElement olivebutton = driver.findElement(By.xpath(".//*[@class='ui olive button']"));
		Assert.assertEquals(olivebutton.getText(), "Olive");
	}

	@Test(dependsOnMethods = { "pageTitle" }, groups = { "buttonTests" })
	public void brownColor() {

		WebElement color5 = driver.findElement(By.xpath(".//*[contains(text(),'Brown')]"));
		Assert.assertEquals(color5.getCssValue("color"), "rgba(255, 255, 255, 1)");
	}

	@BeforeClass(alwaysRun = true)
	public void beforeClass() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SovanPal\\Documents\\drivers\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
		driver.manage().window().maximize();
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {

		driver.close();
	}

}
